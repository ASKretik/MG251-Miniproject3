# 5-minute video script (4 speakers × ~75 seconds)

Arc: **the puzzle** (the optimiser loses to 1/N) → **why** (estimation error) → **what factor models explain**
→ **the fix and what it bought**. Each part is ~180–190 words, about 75 seconds at a natural pace.
`[Show: …]` lines are screen cues, not spoken. Replace [A]–[D] with names.

---

## Speaker A — Data and estimation (0:00 – 1:15)
*Owns Phases 1–2*

[Show: title slide, then the stock list]

Hi, we're [team name]. Our project asks a simple question: if you run Markowitz's mean–variance optimiser on
real stocks, does the "optimal" portfolio actually win?

We picked seventeen large US stocks from ten sectors. That means Apple and Microsoft, but also deliberate laggards
like Citigroup, Intel and Ford, so we're not just picking today's winners. We downloaded twenty years of monthly
adjusted prices, 2006 to 2025, from Yahoo Finance, and the factor data straight from Kenneth French's library. We
estimate everything on the first ten years, which include 2008, and test on the second ten, which include COVID.
Nothing from the test period ever touches the weights.

[Show: Fig 01 — mean returns with confidence intervals]

Before optimising, we asked how well we can even measure the inputs. Each bar is a stock's average annual return
with a 95% confidence interval. The intervals are huge: ten of seventeen include zero. The typical standard error is
65% of the mean itself, but only 7% of the volatility. To pin a mean down to plus or minus two percent, you'd need
almost 400 years of data.

So the optimiser needs 170 inputs, and the most important ones, the means, are mostly noise. Over to [B].

---

## Speaker B — The optimiser and the out-of-sample test (1:15 – 2:30)
*Owns Phases 3–4*

[Show: Fig 02 — efficient frontier]

On training data, the optimiser looks brilliant. Each dot is one of twenty thousand random portfolios, and none
reach the efficient frontier. The max-Sharpe portfolio with short selling promises a Sharpe ratio of 1.55, more
than three times the market's over the same years. But look at its weights: a third in Coca-Cola, a third in
Home Depot, and 27% short Citigroup.

[Show: Fig 04 — predicted vs realised Sharpe]

So we froze those weights and ran them on 2016 to 2025. Light bars are what training predicted; dark bars are
what actually happened. Max-Sharpe fell from 1.55 to 0.73, the worst of all our strategies, while naive equal
weighting got 0.98. Swapping the two halves was even worse: promised 2.02, delivered 0.58.

[Show: Fig 12 — wobbling frontier (our own visual)]

Why? We resampled the training months two hundred times. Every orange dot is where max-Sharpe lands: it's
everywhere. The green minimum-variance dots, which ignore means, stay tightly packed. Nudge Coca-Cola's mean by one
standard error and 110% of the portfolio moves. The optimiser is an error maximiser. [C] will show what factor
models say about expected returns.

---

## Speaker C — CAPM, Fama–French and the French portfolios (2:30 – 3:45)
*Owns Phases 5–6*

[Show: Fig 05 — beta vs average return]

The CAPM says expected return should rise in line with beta. The orange line is the CAPM's prediction for our
stocks; the dashed line is what we found. The slope is 2.8% per unit of beta instead of 10.2%, and beta explains
only 5% of the differences. But seventeen noisy stocks is a weak test, so we turned to Fama and French's 25
size-and-value portfolios and 10 momentum portfolios, going back to 1963.

[Show: Fig 07 — CAPM vs FF3 alpha heatmap]

This heatmap shows each portfolio's CAPM pricing error, and it isn't random. Small value stocks earn 5.6% a year
more than the CAPM predicts; small growth stocks earn 6.4% less. Adding the size and value factors, the
Fama–French three-factor model, cuts the average error from 2.3% to about 1%, and most of the pattern disappears.
Momentum portfolios need a fourth factor: with it, past losers' error shrinks from minus 12.6% to minus 3.2%.

The GRS test still rejects every model, so none is perfect. And a factor isn't always a premium: the size factor
earned 3.4% a year before it was published in 1981 and almost nothing since. [D] shows how factors fix the
optimiser.

---

## Speaker D — Factor covariance and conclusion (3:45 – 5:00)
*Owns Phase 7*

[Show: parameter-count table, 125,250 vs 2,006]

Factor models don't just explain returns; they simplify risk. Instead of estimating every covariance separately,
we assume stocks move together only through a few factors. For five hundred stocks, that's about two thousand
numbers instead of a hundred and twenty-five thousand.

[Show: Fig 08 — bootstrap weight stability]

We resampled our training history five hundred times and recomputed the minimum-variance weights. Orange uses the
sample covariance, blue the three-factor model. The blue boxes are half as wide: the average uncertainty in each
weight falls from 23 to 12 percentage points.

[Show: Fig 09 — rolling GMV weights]

Re-estimating every month on a five-year window, sample weights thrash around while factor weights drift smoothly.
Turnover drops from 30% to 11% a month, and realised risk falls from 14.7% to 13%. To be honest, in our sample
that safer portfolio also had a slightly lower Sharpe ratio, because minimum variance targets risk, not return.

[Show: closing slide with the three takeaways]

So why do we need factor models? They explain returns the CAPM can't, they shrink what we must estimate, and they
turn an error-maximising optimiser into stable portfolios. Thanks for watching.

---

### Timing tips
- Rehearse with a timer; if a part runs long, cut the bracketed figure description rather than the numbers.
- Every number above is in `report/tables/09_headline_numbers.csv` or the table named in the notebook, so each
  speaker can trace and explain it if asked.
- Each speaker should also be ready to explain one other speaker's section (the brief requires everyone to
  understand every number).
